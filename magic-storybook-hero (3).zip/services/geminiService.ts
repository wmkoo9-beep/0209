
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateChapterImage = async (base64Image: string, prompt: string): Promise<string> => {
  const ai = getAI();
  const imageData = base64Image.split(',')[1] || base64Image;

  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: imageData,
    },
  };

  const textPart = {
    text: `Create a professional children's storybook illustration. 
    STYLE: Soft watercolor with warm lighting and artistic textures.
    CHARACTER: The protagonist MUST have the EXACT facial features, hairstyle, and likeness of the child in the attached photo. 
    EXPRESSION & SCENE: ${prompt}
    Ensure the illustration looks high-end, magical, and captures the specific emotions requested in the prompt.`,
  };

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: [imagePart, textPart] },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }

  throw new Error("이미지를 생성할 수 없습니다. 잠시 후 다시 시도해주세요.");
};
